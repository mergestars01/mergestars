import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { randomUUID } from 'node:crypto';
import { generateAnswer, ROLES } from './providers.mjs';

const env = process.env;
const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const host = env.HOST || '127.0.0.1';
const port = Number(env.PORT || 8787);
const coreUrl = env.CORE_SESSION_INTROSPECTION_URL;
const siteOrigin = (env.SITE_ORIGIN || 'https://mergestars.com').replace(/\/$/, '');
const MAX_BODY = 3_900_000;
const rolling = new Map(); // illustrative per-process limiter; use shared Redis / WAF in production

function json(res, status, obj) {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options':'nosniff' });
  res.end(JSON.stringify(obj));
}
function safeOrigin(req) {
  const origin = req.headers.origin;
  // No browser CORS permission is granted; require expected Origin for any browser-triggered POST.
  return !origin || origin === siteOrigin || origin === `http://localhost:${port}` || origin === `http://127.0.0.1:${port}`;
}
async function bodyJSON(req) {
  let len = 0; const chunks = [];
  for await (const chunk of req) {
    len += chunk.length;
    if (len > MAX_BODY) throw Object.assign(new Error('Payload too large'), { status:413 });
    chunks.push(chunk);
  }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); }
  catch { throw Object.assign(new Error('Invalid JSON'), { status:400 }); }
}
async function validateCoreSession(authorization) {
  if (!coreUrl || !coreUrl.startsWith('https://')) return null;
  if (!/^Bearer [A-Za-z0-9._~+\/-]+={0,2}$/i.test(authorization || '')) return null;
  const controller = new AbortController(); const timeout = setTimeout(() => controller.abort(), 5000);
  try {
    const response = await fetch(coreUrl, { method:'GET', headers:{authorization}, signal:controller.signal });
    if (!response.ok) return null;
    const user = await response.json();
    if (user.authenticated !== true || typeof user.user_id !== 'string' || !user.user_id) return null;
    // This user_id is returned by trusted CORE, never accepted from a browser request body.
    return { userId: user.user_id };
  } catch { return null; } finally { clearTimeout(timeout); }
}
function withinLimit(userId) {
  const now = Date.now(); const p = rolling.get(userId) || { t:now, n:0 };
  if (now - p.t > 60_000) { p.t=now; p.n=0; }
  p.n++; rolling.set(userId, p);
  return p.n <= 15;
}
function textValue(x) { return typeof x === 'string' ? x.trim() : ''; }
const server = http.createServer(async (req,res) => {
  const id=randomUUID();
  const url=new URL(req.url || '/', `http://${host}:${port}`);
  try {
    if (req.method==='GET' && url.pathname==='/health') return json(res,200,{status:'ok',mode:'integration-starter',requestId:id});
    if (req.method==='GET' && ['/', '/preview.html','/widget.css','/widget.js'].includes(url.pathname)) {
      const file = url.pathname==='/' ? '/preview.html' : url.pathname;
      const contentTypes = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8'};
      const buf = await readFile(join(root,'public', file.slice(1)));
      const extension=file.substring(file.lastIndexOf('.'));
      res.writeHead(200,{'content-type':contentTypes[extension], 'x-content-type-options':'nosniff', 'cache-control':'no-store'});
      return res.end(buf);
    }
    if (req.method!=='POST' || url.pathname!=='/api/ai/ask') return json(res,404,{error:'not_found',requestId:id});
    if (!safeOrigin(req)) return json(res,403,{error:'origin_blocked',requestId:id});
    if (!(req.headers['content-type'] || '').startsWith('application/json')) return json(res,415,{error:'json_required',requestId:id});
    const user = await validateCoreSession(req.headers.authorization);
    if (!user) return json(res,401,{error:'core_login_required',requestId:id});
    if (!withinLimit(user.userId)) return json(res,429,{error:'rate_limited',requestId:id});
    const b=await bodyJSON(req);
    const role=textValue(b.role);
    const message=textValue(b.message);
    if (!ROLES.includes(role) || !message || message.length > 4000) return json(res,400,{error:'invalid_role_or_message',requestId:id});
    if (b.imageDataUrl && (typeof b.imageDataUrl !== 'string' || b.imageDataUrl.length > 3_600_000)) return json(res,413,{error:'invalid_image',requestId:id});
    // No CORE modifications, payments, commissions, publishing or social network writes.
    const answer=await generateAnswer({role,message,imageDataUrl:b.imageDataUrl});
    return json(res,200,{ ...answer, requestId:id, advisoryOnly:true });
  } catch (error) {
    const status=error.status || (error.message?.includes('configuration') ? 503 : 502);
    // Avoid leaking upstream detail, tokens, image data, or user conversation in logs.
    console.error(`[MERGE AI] request=${id} status=${status} class=${error.constructor.name}`);
    return json(res,status,{error: status===503 ? 'provider_not_configured' : status===413 ? 'payload_too_large' : 'temporary_unavailable',requestId:id});
  }
});
server.listen(port,host,()=>console.log(`MERGE AI starter at http://${host}:${port} (CORE session mandatory)`));
