const providers = new Set(['openai', 'anthropic', 'gemini']);
export const ROLES = Object.freeze(['concierge', 'brand', 'marketing', 'design', 'support', 'vision']);

const instructions = {
  concierge: 'Be MERGE STARS private luxury-museum AI concierge. Answer concisely in the user language, default Georgian. Explain what is verified versus planned. You have no access to order data unless a separate verified CORE tool is introduced.',
  brand: 'Help create and improve an independent MERGE Brand House and product catalog. Respect creator attribution, original immutability, lineage, QR passport policy, and private-first design saves. Suggest only; never claim a save was made.',
  marketing: 'Act as a premium brand PR and social-content drafting assistant. Provide platform-adapted copy, design brief, hashtags, approval checklist. Never claim posting, budget spend, or contact outreach happened.',
  design: 'Help with 3D product design briefs, mosaic scale selection, fit and material disclosure. Do not claim Meshy tasks were executed, a production-ready file exists, or material certification was verified.',
  support: 'Explain MERGE site journey, customer support and transparent order status. Never invent a customer-specific order, refund, KYC result, commission balance or delivery date.',
  vision: 'Analyze an explicitly user-submitted still image. Describe visible features and uncertainty. Do not claim continuous camera access, biometric identification or certified material assessment.'
};
export function rolePrompt(role) {
  if (!ROLES.includes(role)) throw new Error('Unsupported role');
  return `${instructions[role]} System of record is existing MERGE CORE. No Order => No Production => No Financial Exposure. Phase 1 registration and design storage do not create verified commission. Unpaid/deferred is not paid. AI is advisory only; it cannot authorize production or make financial commitments. The official company logo is immutable and must be supplied as an exact approved asset, never improvised. Avoid presenting MERGE COIN as a cryptocurrency.`;
}
export function providerForRole(role, env = process.env) {
  if (!ROLES.includes(role)) throw new Error('Unsupported role');
  const selected = (env[`PROVIDER_${role.toUpperCase()}`] || env.MERGE_AI_DEFAULT_PROVIDER || 'openai').trim().toLowerCase();
  if (!providers.has(selected)) throw new Error('AI provider configuration not supported');
  return selected;
}

async function postJSON(url, headers, body) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 22000);
  try {
    const response = await fetch(url, { method: 'POST', headers: { 'content-type':'application/json', ...headers }, body: JSON.stringify(body), signal: controller.signal });
    if (!response.ok) {
      // Never leak third-party API errors, request payloads, or credentials to the client.
      throw new Error(`Provider HTTP ${response.status}`);
    }
    return await response.json();
  } finally { clearTimeout(timeout); }
}
function imageContentPart(imageDataUrl) {
  if (!imageDataUrl) return null;
  const match = /^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/.exec(imageDataUrl);
  if (!match) throw new Error('Supported camera image types: png, jpeg, webp');
  if (match[2].length > 3_500_000) throw new Error('Image too large (maximum ~2.6 MB)');
  return { mime: match[1], base64: match[2] };
}
export async function generateAnswer({ role, message, imageDataUrl, env = process.env }) {
  const provider = providerForRole(role, env);
  const system = rolePrompt(role);
  const image = imageContentPart(imageDataUrl);
  if (image && role !== 'vision') throw new Error('Images may only be sent in the Vision role');
  if (provider === 'openai') {
    if (!env.OPENAI_API_KEY || !env.OPENAI_MODEL) throw new Error('OpenAI server configuration missing');
    const content = [{ type: 'input_text', text: message }];
    if (image) content.push({ type: 'input_image', image_url: imageDataUrl });
    const data = await postJSON('https://api.openai.com/v1/responses', { authorization: `Bearer ${env.OPENAI_API_KEY}` }, {
      model: env.OPENAI_MODEL, instructions: system, input: [{ role: 'user', content }], max_output_tokens: 1000, store: false
    });
    const answer = (data.output || []).flatMap(o => o.content || []).filter(c => c.type === 'output_text').map(c => c.text).join('\n').trim();
    if (!answer) throw new Error('Provider returned no text');
    return { answer, provider, model: env.OPENAI_MODEL };
  }
  if (provider === 'anthropic') {
    if (!env.ANTHROPIC_API_KEY || !env.ANTHROPIC_MODEL) throw new Error('Anthropic server configuration missing');
    const content = [];
    if (image) content.push({ type: 'image', source: { type:'base64', media_type: image.mime, data:image.base64 } });
    content.push({ type: 'text', text: message });
    const data = await postJSON('https://api.anthropic.com/v1/messages', {
      'x-api-key': env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01'
    }, { model: env.ANTHROPIC_MODEL, max_tokens: 1000, system, messages: [{ role: 'user', content }] });
    const answer = (data.content || []).filter(c => c.type === 'text').map(c => c.text).join('\n').trim();
    if (!answer) throw new Error('Provider returned no text');
    return { answer, provider, model: env.ANTHROPIC_MODEL };
  }
  if (!env.GEMINI_API_KEY || !env.GEMINI_MODEL) throw new Error('Gemini server configuration missing');
  const parts = [{ text: message }];
  if (image) parts.push({ inline_data: { mime_type: image.mime, data: image.base64 } });
  const model = encodeURIComponent(env.GEMINI_MODEL);
  const data = await postJSON(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
    'x-goog-api-key': env.GEMINI_API_KEY
  }, { systemInstruction: { parts: [{ text: system }] }, contents: [{ role: 'user', parts }] });
  const answer = (data.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('\n').trim();
  if (!answer) throw new Error('Provider returned no text');
  return { answer, provider, model: env.GEMINI_MODEL };
}
