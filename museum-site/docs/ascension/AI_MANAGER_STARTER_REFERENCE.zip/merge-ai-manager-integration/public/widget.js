/* MERGE AI UI: a framework-free Shadow DOM widget; no unofficial CORE writes. */
(() => {
  const source = document.currentScript?.src || '';
  const cssUrl = source ? new URL('widget.css', source).href : './widget.css';
  const roles = [
    ['concierge','კონსიერჟი'],['brand','Brand House'],['marketing','PR / სოცქსელები'],
    ['design','3D დიზაინი'],['support','დახმარება'],['vision','ხედვა']
  ];
  class MergeAIManager extends HTMLElement {
    constructor() { super(); this.attachShadow({mode:'open'}); this.selected='concierge'; this.image=null; this.loading=false; }
    connectedCallback(){ this.render(); }
    render(){
      const s=this.shadowRoot;
      const link=document.createElement('link');link.rel='stylesheet';link.href=cssUrl;s.append(link);
      const root=document.createElement('div');root.innerHTML=`
      <button class="launch" type="button" aria-expanded="false"><span>✦</span> MERGE AI MANAGER</button>
      <section class="panel" hidden aria-label="MERGE AI Manager">
        <header class="top"><div class="seal" aria-hidden="true">✦</div><div class="head"><b>MERGE AI</b><small>YOUR PERSONAL BRAND MANAGER</small><em> · PRIVATE ASSISTANT</em></div><button class="iconbtn close" title="დახურვა" aria-label="დახურვა">×</button></header>
        <nav class="roles" aria-label="AI როლები"></nav>
        <div class="tabnote">AI პასუხობს და ამზადებს პროექტებს. ქსელში გამოქვეყნება, გადახდა და CORE ცვლილებები ამ მოდულში გამორთულია.</div>
        <div class="conversation" role="log" aria-live="polite"></div><div class="status" role="status"></div>
        <div class="compose"><textarea aria-label="შეტყობინება" maxlength="4000" placeholder="რა გავაკეთოთ თქვენს ბრენდში?"></textarea>
        <div class="row"><div class="group"><label class="mini photo" title="ნებართვით გაგზავნე ფოტო">📷 ფოტო<input class="file" type="file" accept="image/png,image/jpeg,image/webp" capture="environment" /></label><button class="mini mic" type="button" title="მიკროფონი">🎙 საუბარი</button><button class="clear" type="button">გასუფთავება</button></div><button class="send" type="button">გაგზავნა ↗</button></div>
        <div class="attach"></div></div><div class="footer">MERGE CORE remains authoritative • explicit consent • no auto-posts</div>
      </section>`;
      s.append(root); this.$ = (selector) => s.querySelector(selector);
      this.$('.roles').replaceChildren(...roles.map(([id,title]) => {const b=document.createElement('button');b.className='role';b.type='button';b.textContent=title;b.dataset.role=id;b.setAttribute('aria-pressed',id===this.selected?'true':'false');b.addEventListener('click',()=>this.setRole(id));return b;}));
      this.$('.launch').addEventListener('click',()=>this.toggle(true));
      this.$('.close').addEventListener('click',()=>this.toggle(false));
      this.$('.send').addEventListener('click',()=>this.send());
      this.$('textarea').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();this.send();}});
      this.$('.clear').addEventListener('click',()=>{this.$('.conversation').replaceChildren();this.$('.status').textContent='';this.$('textarea').value='';this.image=null;this.$('.attach').textContent='';this.intro();});
      this.$('.file').addEventListener('change',e=>this.loadImage(e.target.files?.[0]));
      this.$('.mic').addEventListener('click',()=>this.microphone());
      this.intro();
    }
    toggle(open){this.$('.panel').hidden=!open;this.$('.launch').setAttribute('aria-expanded',String(open));if(open)this.$('textarea').focus();}
    setRole(role){this.selected=role;this.$('.roles').querySelectorAll('.role').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.role===role)));this.$('.status').textContent=role==='vision'?'ხედვა მუშაობს მხოლოდ თქვენს მიერ გამოგზავნილ ფოტოზე.':'';this.image=null;this.$('.attach').textContent='';}
    intro(){this.bubble('გამარჯობა! მე ვარ MERGE AI — თქვენი პირადი კონსიერჟი. შემიძლია იდეების, ბრენდის, დიზაინისა და PR-ის მომზადებაში დახმარება. რეალური AI-ს გასააქტიურებლად საჭიროა ავტორიზაცია MERGE CORE-ში და სერვერის კონფიგურაცია.','bot');}
    bubble(text,kind){const p=document.createElement('div');p.className=`bubble ${kind==='you'?'you':''}`;p.textContent=text;this.$('.conversation').append(p);this.$('.conversation').scrollTop=this.$('.conversation').scrollHeight;}
    async loadImage(file){if(!file)return; if(this.selected!=='vision'){this.$('.status').textContent='ფოტოს გასაგზავნად აირჩიეთ „ხედვა“.';return;}
      if(!['image/png','image/jpeg','image/webp'].includes(file.type)||file.size>2_300_000){this.$('.status').textContent='გამოიყენეთ PNG/JPEG/WEBP, მაქს. 2.3 MB.';return;}
      const data=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsDataURL(file)});
      this.image=data;this.$('.attach').textContent='ფოტო შერჩეულია. გაიგზავნება მხოლოდ „გაგზავნა“-ზე დაჭერით.';this.$('.status').textContent='';
    }
    microphone(){const API=window.SpeechRecognition||window.webkitSpeechRecognition;if(!API){this.$('.status').textContent='ამ ბრაუზერში ხმოვანი შეყვანა მიუწვდომელია.';return;}
      // Browser-native transcription may use the browser vendor's speech service: consent is required.
      if(!confirm('ჩართოთ მიკროფონი? საუბრის ამოცნობა შეიძლება ბრაუზერის სერვისით განხორციელდეს.'))return;
      const rec=new API();rec.lang='ka-GE';rec.interimResults=false;rec.onresult=e=>{this.$('textarea').value=e.results[0][0].transcript;};rec.onerror=()=>{this.$('.status').textContent='ხმის ამოცნობა ვერ მოხერხდა.'};rec.start();
    }
    async send(){if(this.loading)return;const input=this.$('textarea');const message=input.value.trim();if(!message&&!this.image)return;
      const cfg=window.MERGE_AI_CONFIG||{};const getToken=cfg.getAccessToken;
      const token=typeof getToken==='function'?await getToken():null;
      if(!token){this.$('.status').textContent='ჯერ CORE-ში ავტორიზაციაა საჭირო. დეველოპერმა უნდა დააკავშიროს getAccessToken().';return;}
      this.loading=true;this.$('.send').disabled=true;this.$('.status').textContent='AI ამზადებს პასუხს…';this.bubble(message+(this.image?' [ფოტო]':''),'you');input.value='';
      try{const base=cfg.apiBase||'';const response=await fetch(`${base}/api/ai/ask`,{method:'POST',headers:{'content-type':'application/json',authorization:`Bearer ${token}`},body:JSON.stringify({role:this.selected,message:message||'აღწერე ფოტოზე გამოსახული პროდუქტი',imageDataUrl:this.image})});
        const data=await response.json();if(!response.ok)throw new Error(data.error||'connection_failed');
        this.bubble(data.answer,'bot');this.$('.status').textContent=`პასუხი: ${data.provider}. ეს რჩევაა და არა CORE მოქმედება.`;this.image=null;this.$('.attach').textContent='';
      }catch(e){this.$('.status').textContent=`ვერ შესრულდა: ${e.message}. CORE ჩანაწერები უცვლელია.`;}
      finally{this.loading=false;this.$('.send').disabled=false;}
    }
  }
  if(!customElements.get('merge-ai-manager')) customElements.define('merge-ai-manager',MergeAIManager);
})();
