# MERGE STARS — AI MANAGER MODULE (private integration v0.1)

**DO NOT DEPLOY DIRECTLY TO PRODUCTION. DO NOT REBUILD MERGE CORE.**

Target: integrate a single assistant surface on the existing mergestars.com website, Living Museum, and the authenticated Brand House experience. The module implements an embeddable Shadow DOM widget and a Node 20 server adapter for OpenAI, Anthropic, and Gemini.

**Implemented in this package:** UI + chat, role-based prompts, opt-in still-image analysis, browser-dependent speech transcription, server auth-introspection boundary, supplier API adapters, local preview and basic unit tests. **Not implemented:** production connection to CORE, actual OAuth, social posting, live Realtime conversation, Meshy generation, order reads/writes, or physical wearable hardware. Never label stubs as working integrations.

**Integration sequence:** (1) inspect existing repo, Auth and 3D layout; (2) add widget asset and API reverse proxy on private staging; (3) implement CORE session introspection + approved scope; (4) configure secure API keys and actual model IDs on backend; (5) test every provider and vision uploads; (6) build user-confirmed workflows with audit; (7) founder review; (8) controlled deploy.

**Action policy:** AI text is advisory and may draft. Side effects require explicit user approval, service OAuth authorization, per-house RBAC, idempotent commands, audit logs, and rollback/reversal rules. Always preserve source attribution, immutability of original products and CORE payments.
