# MERGE ⭐ STARS — AI MANAGER integration starter v0.1

**სტატუსი: დეველოპერებისთვის მომზადებული მოდული. არ არის mergestars.com-ზე განთავსებული.**

## მიზანი
არსებულ MERGE CORE + Living Museum-ზე დამოუკიდებელი AI ფენის დამატება, არა CORE-ის რეგენერაცია. ამ პაკეტის browser widget აჩვენებს: კონსიერჟს, Brand House დამხმარეს, PR-ს, დიზაინს, მხარდაჭერასა და მომხმარებლის მიერ ატვირთული ფოტოს ანალიზს. Backend შეუძლია OpenAI / Anthropic / Google Gemini provider-თან text და image მოთხოვნები შესაბამისი server key-ით. პირველი დანერგვა უნდა მოხდეს private staging-ზე.

## რაც ფაქტობრივად ამ პაკეტშია
- `public/preview.html`: ადგილობრივი ვიზუალური გადახედვა მუზეუმის შავი/ვერცხლის/თბილი ოქროს სტილში.
- `public/widget.js` / `widget.css`: რეალური UI, როლების გადართვა, შეტყობინება, ნებართვით ფოტოს არჩევა, მხარდაჭერილ ბრაუზერებში ხმის ამოცნობა.
- `server/providers.mjs`: სამი provider-ის server-side adapter (OpenAI Responses / Anthropic Messages / Gemini generateContent); მოდელები განისაზღვრება **API-ში რეალურად ხელმისაწვდომი ID-ებით**, არა ChatGPT-ის მომხმარებლის რეჟიმის სახელებით.
- `server/server.mjs`: ავტორიზაციის გარე CORE შემოწმება, როლების ვალიდაცია, origin check, ზომის ლიმიტები და შეზღუდული rate limiting.
- `test/`: უსაფრთხოების საზღვრის საბაზისო ავტომატური ტესტები.

## როგორ ნახონ დეველოპერებმა
Node.js 20 ან ახალი: `npm test`, შემდეგ `npm start` (თუ `.env` ინიციალიზებულია), გახსენით `http://127.0.0.1:8787/`.
ეს არის ვიზუალური გადახედვა. ავტორიზაციის გარეშე შეტყობინება სერვერზე **არ** შესრულდება. Node არ ტვირთავს `.env` ფაილს ავტომატურად; დეველოპერმა შეიძლება გამოიყენოს `node --env-file=.env server/server.mjs` ან გარემოს მართვა hosting-ზე.

## MERGE CORE-თან შეერთების კონტრაქტი
1. საიტის მთავარ layout-ში ჩასვით `/merge-ai/widget.js`, `/merge-ai/widget.css` (არსებული build pipeline-ის თანახმად) და `<merge-ai-manager></merge-ai-manager>`.
2. ავტორიზაციის შემდეგ `window.MERGE_AI_CONFIG = { apiBase: '/merge-ai', getAccessToken: async () => /* CORE-ის access token */ }` უნდა განისაზღვროს widget-ის გამოყენებამდე. არასოდეს ჩადოთ provider API secret ბრაუზერში.
3. reverse proxy-მ `POST /merge-ai/api/ai/ask` უნდა მიაბას private backend-ს (`http://127.0.0.1:8787/api/ai/ask`); `GET /merge-ai/widget.js`, `GET /merge-ai/widget.css` static asset-ებია. ალტერნატივად backend-ის static route-ებიც გამოიყენება ადგილობრივ preview-ში.
4. აუცილებელია **ნამდვილი** `CORE_SESSION_INTROSPECTION_URL` (HTTPS). `GET` + `Authorization: Bearer <token>`-ზე CORE აბრუნებს `{ "authenticated": true, "user_id": "..." }` ან 401-ს. ეს endpoint ნიმუშია — არსებულ CORE-ს უნდა მოერგოს. ბრაუზერიდან გადმოცემული house/user_id არასოდეს მიიჩნიოთ ჭეშმარიტებად.
5. `SITE_ORIGIN=https://mergestars.com`; production-ში დაამატეთ shared rate limiting, CSRF/abuse controls, WAF, audit events, request tracing, privacy notices, explicit retention policies, monitoring და budget caps.
6. შეამოწმეთ Content Security Policy, browser camera/mic permission, accessibility, mobile, RTL/locale, and error handling. ქარხნის/გადახდის/კომისიის სერვისებს AI adapter-ი პირდაპირ ვერ მიმართავს.

## რისი გაკეთება რჩება დეველოპერებს (ამ პაკეტით გაკეთებულად არ ჩაითვალოს)
- repo/hosting-ზე ჩასმა, staging და production CI/CD, CORE bearer ავტორიზაციის ინტეგრირება, RBAC ყველა სახლისთვის და isolation, session handling.
- 3D Meshy რეალური API, task IDs, QUEUED/GENERATING/READY/FAILED, server-side credentials და model preview Three.js-ის ვიტრინაში.
- ავტორიზებული OAuth სოციალური ანგარიშები (Meta, Instagram, YouTube და ა.შ.), drafts/approval queue, publish scheduling, rate limits, audit, webhook retries; **არ არის** რეალური autoposting.
- კამერიდან უწყვეტი ვიდეო/Realtime აუდიო შესაბამისი მოწყობილობისა და კონფიდენციალურობის პოლიტიკით; აქ ვიდეოკამერის უწყვეტი ჩაწერა არ ხდება, ფოტოს გაგზავნა ხელითაა.
- ნამდვილ CORE-ში წვდომის მხოლოდ მინიმალური, scoped read tools; ნებისმიერი ცვლილება მხოლოდ ცალკე დამტკიცებული ადამიანური ბრძანებით და იდემპოტენტური backend endpoint-ით.
- მოსახსნელი ფიზიკური MERGE COIN-ის BLE/NFC/secure pairing: ცალკე hardware პროექტია; გვირგვინის, ქამრისა და საათის სახით პროდუქტის დიზაინები აქ არ იწარმოება.
- კანონიკური ლოგოს ორიგინალი ფაილის ჩასმა (არ გენერირდება ახალი ლოგო).

## უსაფრთხოების უცვლელი კანონები
- CORE NEVER GETS REGENERATED.
- No Order → No Production → No Financial Exposure.
- No Verified Funds → No Production Authorization.
- CONCEPT ≠ ESTIMATED ≠ VERIFIED.
- Order Created ≠ Payment Verified ≠ Commission Available.
- AI cannot execute payments, financial promises, publication, production authorizations, or mutate original/source product lineage.
- თითო Brand House-ს ეძლევა მხოლოდ საკუთარი უფლებების ფარგლებში წვდომა, მომხმარებლის თანხმობით.
- QR/Passport და tracking მხოლოდ უკვე დადასტურებული CORE ჩანაწერებიდან.

## API დოკუმენტაცია (გადამოწმდეს ინტეგრაციის დღეს)
- OpenAI Responses: https://platform.openai.com/docs/api-reference/responses
- Anthropic Messages: https://docs.anthropic.com/en/api/messages
- Gemini GenerateContent: https://ai.google.dev/api/generate-content

**პროდუქციის ბირთვის ნებისმიერი შეცვლა საჭიროებს კოდის მიმოხილვას, კერძო staging-ის ტესტს და დამფუძნებლის თანხმობას.**
