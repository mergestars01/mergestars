import test from 'node:test';import assert from 'node:assert/strict';
import {ROLES, providerForRole, rolePrompt,generateAnswer} from '../server/providers.mjs';
test('six distinct roles',()=>{assert.equal(ROLES.length,6);assert.equal(new Set(ROLES).size,6)});
test('provider routing cannot be set by request',()=>{
  assert.equal(providerForRole('marketing',{MERGE_AI_DEFAULT_PROVIDER:'openai',PROVIDER_MARKETING:'anthropic'}),'anthropic');
  assert.throws(()=>providerForRole('finance',{MERGE_AI_DEFAULT_PROVIDER:'openai'}));
});
test('financial and CORE boundary exists in each role',()=>{
 for(const role of ROLES){assert.match(rolePrompt(role),/No Order => No Production/);assert.match(rolePrompt(role),/cannot authorize production/);}
});
test('no provider key causes closed failure rather than fabricated answer',async()=>{
  await assert.rejects(generateAnswer({role:'concierge',message:'hi',env:{MERGE_AI_DEFAULT_PROVIDER:'openai'}}),/configuration missing/);
});
test('image only permitted in vision role',async()=>{
  await assert.rejects(generateAnswer({role:'marketing',message:'hi',imageDataUrl:'data:image/jpeg;base64,YWJj',env:{MERGE_AI_DEFAULT_PROVIDER:'openai'}}),/Vision role/);
});
